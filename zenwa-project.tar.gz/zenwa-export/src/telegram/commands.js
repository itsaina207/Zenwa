/**
 * Telegram bot command handlers
 */

const { createAccount, getBalance, sendHbar } = require('../hedera/account');
const { getTransactionHistory } = require('../hedera/transactions');
const { mintToken, sendToken, associateToken } = require('../hedera/tokens');
const { createTopic, submitTopicMessage, getTopicMessages } = require('../hedera/topic-management');
// Fonctionnalités d'airdrop réactivées avec TokenAirdropTransaction
const { createTokenAirdrop, claimTokenAirdrop } = require('../hedera/airdrop');
// const { 
//   createCampaign, 
//   getCampaign, 
//   getActiveCampaigns, 
//   getUserCampaigns,
//   claimFromCampaign,
//   updateCampaignStatus
// } = require('../hedera/campaigns');
const { analyzeIntent, isBalanceCheck, isHistoryCheck, isCreateTokenRequest, isGetAirdropsRequest, isCreateAirdropRequest, isElizaQuery, processWithEliza } = require('../services/openai-service');
const { LANGUAGES, translate, setUserLanguage, getUserLanguage } = require('../utils/localizations');

// Importer les gestionnaires des commandes d'airdrop
// Les campagnes restent désactivées
const airdropModule = require('./airdrop-commands');
const { 
  handleAirdrop,
  handleClaimAirdrop, 
  handleAirdropConversation,
  AIRDROP_STATES,
  CLAIM_STATES 
} = airdropModule;

// Définir des placeholders pour les états des campagnes (toujours désactivées)
const CAMPAIGN_STATES = { NONE: 'none_campaign' };

// State management for multi-step operations
const userState = new Map();

// State for phone number collection during start
const START_STATES = {
  WAITING_FOR_PHONE: 'WAITING_FOR_PHONE',
  NONE: 'NONE'
};

// Possible states for the /send command
const SEND_STATES = {
  WAITING_FOR_ADDRESS_TYPE: 'WAITING_FOR_ADDRESS_TYPE',  // Nouveau: attente du choix du type d'adresse
  WAITING_FOR_ADDRESS: 'WAITING_FOR_ADDRESS',
  WAITING_FOR_AMOUNT: 'WAITING_FOR_AMOUNT',
  NONE: 'NONE'
};

// Possible states for the /mint command
const MINT_STATES = {
  WAITING_FOR_TYPE: 'WAITING_FOR_TYPE',
  WAITING_FOR_NAME: 'WAITING_FOR_NAME',
  WAITING_FOR_SYMBOL: 'WAITING_FOR_SYMBOL',
  WAITING_FOR_SUPPLY: 'WAITING_FOR_SUPPLY',
  NONE: 'NONE'
};

// Possible states for the /sendtoken command
const SEND_TOKEN_STATES = {
  WAITING_FOR_ADDRESS_TYPE: 'WAITING_FOR_ADDRESS_TYPE',
  WAITING_FOR_ADDRESS: 'WAITING_FOR_ADDRESS',
  WAITING_FOR_TOKEN_ID: 'WAITING_FOR_TOKEN_ID',
  WAITING_FOR_AMOUNT: 'WAITING_FOR_AMOUNT',
  NONE: 'NONE'
};

// Possible states for the /associate command
const ASSOCIATE_STATES = {
  WAITING_FOR_TOKEN_ID: 'WAITING_FOR_TOKEN_ID',
  NONE: 'NONE'
};

// Possible states for the /forcetransfer command
const FORCE_TRANSFER_STATES = {
  WAITING_FOR_RECIPIENT: 'WAITING_FOR_RECIPIENT',
  WAITING_FOR_TOKEN_ID: 'WAITING_FOR_TOKEN_ID',
  WAITING_FOR_AMOUNT: 'WAITING_FOR_AMOUNT',
  NONE: 'NONE'
};

/**
 * Handles the /start command
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handleStart(bot, msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const firstName = msg.from.first_name || 'l\'ami';
  const username = msg.from.username || null;
  
  console.log(`Start command from user ${userId}`);
  
  // Vérifier si l'utilisateur a déjà un portefeuille
  const { getWalletByUserId } = require('../storage/userWallets');
  const wallet = await getWalletByUserId(userId);
  
  if (wallet && wallet.phoneNumber) {
    // Utilisateur existant avec numéro de téléphone
    console.log(`Utilisateur ${userId} déjà enregistré avec le numéro ${wallet.phoneNumber}`);
    
    // Utiliser la fonction sendHelpWithButtons du gestionnaire de langue
    const { sendHelpWithButtons } = require('./language/handler');
    await sendHelpWithButtons(bot, userId, chatId, `Rebonjour ${firstName} ! 👋\nVotre numéro de téléphone est déjà enregistré.`);
    return;
  }
  
  if (wallet && !wallet.phoneNumber) {
    // Utilisateur existant sans numéro de téléphone, demander le numéro
    userState.set(userId, {
      state: START_STATES.WAITING_FOR_PHONE,
      chatId: chatId,
      userData: {
        username,
        accountId: wallet.accountId
      }
    });
    
    await bot.sendMessage(
      chatId,
      `Bonjour ${firstName} ! 👋\n\nPour améliorer l'identification sur notre service, veuillez entrer votre numéro de téléphone au format 0XXXXXXXXX ou +336XXXXXXXX:`,
      { 
        reply_markup: { 
          force_reply: true 
        } 
      }
    );
    return;
  }
  
  // Nouvel utilisateur, demander le numéro de téléphone avant de créer un portefeuille
  userState.set(userId, {
    state: START_STATES.WAITING_FOR_PHONE,
    chatId: chatId,
    userData: {
      username
    }
  });
  
  await bot.sendMessage(
    chatId,
    `Bonjour ${firstName} ! 👋\n\nPour créer votre portefeuille Hedera, veuillez d'abord entrer votre numéro de téléphone au format 0XXXXXXXXX ou +336XXXXXXXX:`,
    { 
      reply_markup: { 
        force_reply: true 
      } 
    }
  );
}

/**
 * Handles the /help command
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handleHelp(bot, msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  // Utiliser la fonction sendHelpWithButtons du gestionnaire de langue
  const { sendHelpWithButtons } = require('./language/handler');
  await sendHelpWithButtons(bot, userId, chatId);
}

/**
 * Handles the /createwallet command
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handleCreateWallet(bot, msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const username = msg.from.username || null;
  
  await bot.sendMessage(chatId, 'Création de votre wallet Hedera en cours... Cela peut prendre un moment.');
  
  const result = await createAccount(userId, username);
  
  if (result.success) {
    const message = `
✅ ${result.message}

*Vos informations de compte Hedera :*

Account ID: \`${result.accountId}\`
EVM Address: \`${result.evmAddress}\`

*Clés du compte :*
Private Key: \`${result.privateKey}\`
Public Key: \`${result.publicKey}\`

*Transaction :*
Transaction ID: \`${result.transactionId}\`
[Voir dans l'explorateur](${result.explorerUrl})

IMPORTANT : Conservez ces informations en lieu sûr, surtout la clé privée.
Utilisez /balance pour vérifier votre solde.
`;
    
    await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
  } else {
    await bot.sendMessage(chatId, `❌ ${result.message}`);
  }
}

/**
 * Handles the /balance command
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handleBalance(bot, msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  await bot.sendMessage(chatId, 'Vérification de votre solde en cours...');
  
  const result = await getBalance(userId);
  
  if (result.success) {
    let tokenList = '';
    if (typeof result.balance.tokens === 'string') {
      // Si c'est juste une chaîne (probablement "Aucun token"), l'utiliser telle quelle
      tokenList = result.balance.tokens;
    } else {
      // Sinon, parcourir les tokens et les formater
      console.log(`[DISPLAY_BALANCE] Tokens à afficher: ${JSON.stringify(result.balance.tokens)}`);
      
      const tokenEntries = Object.entries(result.balance.tokens);
      if (tokenEntries.length > 0) {
        // Formater chaque token avec son ID et montant
        tokenList = tokenEntries
          .map(([tokenId, amount]) => {
            // Formatter avec lien HashScan (testnet par défaut)
            const network = 'testnet'; // Nous pouvons aussi importer cette valeur du module de configuration
            return `${tokenId}: ${amount} [Voir sur HashScan](https://hashscan.io/${network}/token/${tokenId})`;
          })
          .join('\n');
      } else {
        tokenList = 'Aucun token';
      }
    }
    
    // Récupérer les informations de l'utilisateur pour avoir son numéro de téléphone
    const { getWalletByUserId } = require('../storage/userWallets');
    const wallet = await getWalletByUserId(userId);
    const phoneNumber = wallet?.phoneNumber || 'Non associé';
    
    const message = `
💰 *Solde de votre Wallet Hedera*

*Informations du compte :*
Account ID: \`${result.accountId}\` (Lié au numéro ${phoneNumber})

*Solde :*
HBAR: ${result.balance.hbars}

*Tokens :*
${tokenList}

Utilisez /send pour envoyer des HBAR à un autre compte.
Utilisez /sendtoken pour envoyer des tokens à un autre compte.
Utilisez /mint pour créer un nouveau token.
`;
    
    await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
  } else {
    await bot.sendMessage(chatId, `❌ ${result.message}`);
  }
}

/**
 * Handles the /send command
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handleSend(bot, msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  // Réinitialiser l'état pour commencer une nouvelle transaction
  userState.set(userId, {
    state: SEND_STATES.WAITING_FOR_ADDRESS_TYPE,
    chatId: chatId,
    addressType: null,
    toAccountId: null,
    amount: null
  });
  
  // Demander le type d'adresse pour l'envoi
  await bot.sendMessage(
    chatId, 
    "Comment souhaitez-vous identifier le destinataire?",
    { 
      reply_markup: {
        keyboard: [
          ['📱 Numéro de téléphone'],
          ['🔢 Adresse Hedera (0.0.xxxx)']
        ],
        one_time_keyboard: true,
        resize_keyboard: true
      }
    }
  );
}

/**
 * Handles the /history command
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handleHistory(bot, msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const args = msg.text.split(' ').slice(1);
  
  const limit = args[0] ? parseInt(args[0], 10) : 5;
  
  await bot.sendMessage(chatId, 'Récupération de votre historique de transactions...');
  
  const result = await getTransactionHistory(userId, limit);
  
  if (result.success) {
    if (result.transactions.length === 0) {
      await bot.sendMessage(
        chatId,
        `Aucune transaction trouvée pour le compte ${result.accountId}`
      );
      return;
    }
    
    let message = `📜 *Historique des Transactions*\n\nCompte: \`${result.accountId}\`\n\n`;
    
    result.transactions.forEach((tx, index) => {
      message += `*${index + 1}. ${tx.type}*\n`;
      message += `Date: ${new Date(tx.timestamp).toLocaleString()}\n`;
      message += `Statut: ${tx.result}\n`;
      message += `Frais: ${tx.fee} HBAR\n`;
      message += `[Voir dans l'explorateur](${tx.explorerUrl})\n\n`;
    });
    
    await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
  } else {
    await bot.sendMessage(chatId, `❌ ${result.message}`);
  }
}

/**
 * Handles the /mint command
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handleMint(bot, msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const args = msg.text.split(' ').slice(1);
  
  // Si des arguments sont fournis, utiliser l'ancienne méthode directe
  if (args.length > 0) {
    const tokenInfo = {};
    
    if (args.length >= 1) tokenInfo.name = args[0];
    if (args.length >= 2) tokenInfo.symbol = args[1];
    if (args.length >= 3) {
      const supply = parseInt(args[2], 10);
      const MAX_SUPPLY = 100000000; // 100 millions
      if (supply > MAX_SUPPLY) {
        await bot.sendMessage(chatId, `⚠️ La supply maximale autorisée est de ${MAX_SUPPLY}. Votre valeur (${supply}) sera limitée à ce maximum.`);
        tokenInfo.initialSupply = MAX_SUPPLY;
      } else {
        tokenInfo.initialSupply = supply;
      }
    }
    
    await bot.sendMessage(chatId, 'Création de votre token en cours... Cela peut prendre un moment.');
    
    const result = await mintToken(userId, tokenInfo);
    
    if (result.success) {
      const message = `
✅ ${result.message}

*Informations du token :*
Token ID: \`${result.tokenId}\`
Nom: ${result.tokenName}
Symbole: ${result.tokenSymbol}
Offre initiale: ${result.initialSupply}

[Voir dans l'explorateur](${result.explorerUrl})

Utilisez /balance pour voir votre nouveau token dans votre portefeuille.
`;
      await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } else {
      await bot.sendMessage(chatId, `❌ ${result.message}`);
    }
    return;
  }
  
  // Sinon, démarrer le processus interactif de création de token
  // Réinitialiser l'état pour commencer une nouvelle création de token
  userState.set(userId, {
    state: MINT_STATES.WAITING_FOR_TYPE,
    chatId: chatId,
    tokenInfo: {
      type: null,
      name: null,
      symbol: null,
      initialSupply: null
    }
  });
  
  // Demander le type de token
  await bot.sendMessage(
    chatId, 
    "Quel type de token souhaitez-vous créer?\n\n1️⃣ - Token Fongible (comme une monnaie, divisible)\n2️⃣ - Token Non-Fongible (NFT, unique)",
    { 
      reply_markup: {
        keyboard: [['1️⃣ Fongible', '2️⃣ Non-Fongible']],
        one_time_keyboard: true,
        resize_keyboard: true
      }
    }
  );
}

/**
 * Handle conversation steps for creating a token
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handleMintConversation(bot, msg) {
  const userId = msg.from.id.toString();
  const userInfo = userState.get(userId);
  const msgChatId = msg.chat.id;
  const text = msg.text.trim();
  
  // Vérifier si l'utilisateur est en cours de processus de création de token
  if (userInfo && userInfo.tokenInfo) {
    // Traitement des étapes de la conversation en cours
    const currentChatId = userInfo.chatId;
    
    // Gestion des différentes étapes de la conversation
    switch (userInfo.state) {
      case MINT_STATES.WAITING_FOR_TYPE:
        // L'utilisateur a choisi le type de token
        let tokenType = '';
        if (text.includes('1') || text.toLowerCase().includes('fongible')) {
          tokenType = 'FUNGIBLE';
        } else if (text.includes('2') || text.toLowerCase().includes('non-fongible') || text.toLowerCase().includes('nft')) {
          tokenType = 'NON_FUNGIBLE';
          await bot.sendMessage(
            currentChatId,
            "Les tokens non-fongibles (NFT) ne sont pas encore supportés. Nous allons créer un token fongible à la place."
          );
          tokenType = 'FUNGIBLE'; // Par défaut pour l'instant
        } else {
          await bot.sendMessage(
            currentChatId,
            "Je n'ai pas compris votre choix. Veuillez choisir 1 pour Fongible ou 2 pour Non-Fongible."
          );
          return;
        }
        
        userInfo.tokenInfo.type = tokenType;
        userInfo.state = MINT_STATES.WAITING_FOR_NAME;
        userState.set(userId, userInfo);
        
        // Demander le nom du token
        await bot.sendMessage(
          currentChatId,
          "Quel nom souhaitez-vous donner à votre token?",
          { reply_markup: { force_reply: true, remove_keyboard: true } }
        );
        return;
        
      case MINT_STATES.WAITING_FOR_NAME:
        // L'utilisateur a fourni le nom du token
        userInfo.tokenInfo.name = text;
        userInfo.state = MINT_STATES.WAITING_FOR_SYMBOL;
        userState.set(userId, userInfo);
        
        // Générer un symbole par défaut
        let suggestedSymbol = '';
        if (text.includes(' ')) {
          // Nom composé, utiliser les initiales
          suggestedSymbol = text.split(' ')
            .map(word => word.charAt(0).toUpperCase())
            .join('');
          
          // Limiter à 5 caractères maximum
          suggestedSymbol = suggestedSymbol.substring(0, 5);
        } else {
          // Nom simple, prendre les 3-4 premières lettres
          suggestedSymbol = text.substring(0, 4).toUpperCase();
        }
        
        // Demander le symbole du token
        await bot.sendMessage(
          currentChatId,
          `Quel symbole souhaitez-vous utiliser pour votre token?\n(Suggestion: ${suggestedSymbol})`,
          { reply_markup: { force_reply: true } }
        );
        return;
        
      case MINT_STATES.WAITING_FOR_SYMBOL:
        // L'utilisateur a fourni le symbole du token
        userInfo.tokenInfo.symbol = text;
        userInfo.state = MINT_STATES.WAITING_FOR_SUPPLY;
        userState.set(userId, userInfo);
        
        // Demander la supply initiale
        await bot.sendMessage(
          currentChatId,
          "Quelle quantité initiale de tokens souhaitez-vous créer?\n(Maximum: 100 000 000, par défaut: 1000)",
          { reply_markup: { force_reply: true } }
        );
        return;
        
      case MINT_STATES.WAITING_FOR_SUPPLY:
        // L'utilisateur a fourni la supply
        let supply = parseInt(text, 10);
        const MAX_SUPPLY = 100000000; // 100 millions
        
        // Valider la supply
        if (isNaN(supply)) {
          supply = 1000; // Valeur par défaut si la conversion échoue
        } else if (supply > MAX_SUPPLY) {
          await bot.sendMessage(
            currentChatId, 
            `⚠️ La supply maximale autorisée est de ${MAX_SUPPLY}. Votre valeur (${supply}) sera limitée à ce maximum.`
          );
          supply = MAX_SUPPLY;
        } else if (supply <= 0) {
          supply = 1000; // Valeur par défaut si négative ou zéro
          await bot.sendMessage(
            currentChatId,
            "La supply doit être positive. Nous utiliserons la valeur par défaut de 1000."
          );
        }
        
        userInfo.tokenInfo.initialSupply = supply;
        
        // Réinitialiser l'état
        userState.set(userId, { ...userInfo, state: MINT_STATES.NONE });
        
        // Créer le token
        await bot.sendMessage(
          currentChatId,
          `Création de votre token en cours...\n\nNom: ${userInfo.tokenInfo.name}\nSymbole: ${userInfo.tokenInfo.symbol}\nOffre initiale: ${userInfo.tokenInfo.initialSupply}\n\nCela peut prendre un moment.`
        );
        
        const result = await mintToken(userId, userInfo.tokenInfo);
        
        if (result.success) {
          const message = `
✅ ${result.message}

*Informations du token :*
Token ID: \`${result.tokenId}\`
Nom: ${result.tokenName}
Symbole: ${result.tokenSymbol}
Offre initiale: ${userInfo.tokenInfo.initialSupply}

[Voir dans l'explorateur](${result.explorerUrl})

Utilisez /balance pour voir votre nouveau token dans votre portefeuille.
`;
          await bot.sendMessage(currentChatId, message, { parse_mode: 'Markdown' });
        } else {
          await bot.sendMessage(currentChatId, `❌ ${result.message}`);
        }
        return;
    }
  }
}

/**
 * Handles the /sendtoken command
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handleSendToken(bot, msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const args = msg.text ? msg.text.split(' ').slice(1) : [];
  
  // Si des arguments sont fournis, utiliser l'ancienne méthode directe
  if (args.length >= 3) {
    const toAccountId = args[0];
    const tokenId = args[1];
    const amount = parseInt(args[2], 10);
    
    await bot.sendMessage(chatId, `Envoi de ${amount} tokens (${tokenId}) à ${toAccountId} en cours...`);
    
    const result = await sendToken(userId, toAccountId, tokenId, amount);
    
    if (result.success) {
      const message = `
✅ ${result.message}

*Détails de la transaction :*
Token ID: \`${result.tokenId}\`
Transaction ID: \`${result.transactionId}\`

[Voir dans l'explorateur](${result.explorerUrl})

Utilisez /balance pour vérifier votre nouveau solde.
`;
      await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } else {
      await bot.sendMessage(chatId, `❌ ${result.message}`);
    }
    return;
  }
  
  // Sinon, démarrer le processus interactif d'envoi de token
  // Étape 1: demander le type d'adresse du destinataire
  userState.set(userId, {
    state: SEND_TOKEN_STATES.WAITING_FOR_ADDRESS_TYPE,
    chatId: chatId,
    addressType: null,
    toAccountId: null,
    tokenId: null,
    amount: null
  });
  
  // Demander le type d'adresse pour l'envoi
  await bot.sendMessage(
    chatId, 
    "Comment souhaitez-vous identifier le destinataire du token?",
    { 
      reply_markup: {
        keyboard: [
          ['📱 Numéro de téléphone'],
          ['🔢 Adresse Hedera (0.0.xxxx)']
        ],
        one_time_keyboard: true,
        resize_keyboard: true
      }
    }
  );
}

/**
 * Handle conversation steps for sending tokens
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handleSendTokenConversation(bot, msg) {
  const userId = msg.from.id.toString();
  const userInfo = userState.get(userId);
  const msgChatId = msg.chat.id;
  const text = msg.text.trim();
  
  // Vérifier si l'utilisateur est en cours de processus d'envoi de token
  if (userInfo) {
    // Traitement des étapes de la conversation en cours
    const currentChatId = userInfo.chatId;
    
    // Gestion des différentes étapes de la conversation
    switch (userInfo.state) {
      case SEND_TOKEN_STATES.WAITING_FOR_ADDRESS_TYPE:
        // L'utilisateur a choisi le type d'adresse à utiliser
        let promptMessage = '';
        
        if (text.includes('Numéro') || text.includes('📱')) {
          // Option numéro de téléphone
          userInfo.addressType = 'PHONE';
          promptMessage = "Entrez le numéro de téléphone du destinataire (format: 0XXXXXXXXX ou +33XXXXXXXXX):";
        } else if (text.includes('Hedera') || text.includes('🔢')) {
          // Option adresse Hedera
          userInfo.addressType = 'HEDERA';
          promptMessage = "Entrez l'adresse Hedera du destinataire (format: 0.0.xxxx):";
        } else {
          // Option non reconnue
          await bot.sendMessage(
            currentChatId,
            "Je n'ai pas compris votre choix. Veuillez sélectionner une des options proposées.",
            { 
              reply_markup: {
                keyboard: [
                  ['📱 Numéro de téléphone'],
                  ['🔢 Adresse Hedera (0.0.xxxx)']
                ],
                one_time_keyboard: true,
                resize_keyboard: true
              }
            }
          );
          return;
        }
        
        // Mettre à jour l'état et demander l'adresse
        userInfo.state = SEND_TOKEN_STATES.WAITING_FOR_ADDRESS;
        userState.set(userId, userInfo);
        
        await bot.sendMessage(
          currentChatId,
          promptMessage,
          { reply_markup: { force_reply: true, remove_keyboard: true } }
        );
        return;
        
      case SEND_TOKEN_STATES.WAITING_FOR_ADDRESS:
        // L'utilisateur a fourni l'adresse de destination
        userInfo.toAccountId = text;
        userInfo.state = SEND_TOKEN_STATES.WAITING_FOR_TOKEN_ID;
        userState.set(userId, userInfo);
        
        // Type d'identifiant utilisé pour le message
        const identifierType = userInfo.addressType === 'PHONE' ? 'numéro de téléphone' : 'adresse Hedera';
        
        // Récupérer les tokens de l'utilisateur pour les afficher
        const { getBalance } = require('../hedera/wallet');
        const balanceResult = await getBalance(userId);
        
        let promptTokenMessage = `Quel token souhaitez-vous envoyer au ${identifierType} ${text}?\nEntrez l'ID du token (format: 0.0.xxxx)`;
        
        // Si l'utilisateur a des tokens, les afficher pour faciliter la sélection
        if (balanceResult.success && typeof balanceResult.balance.tokens === 'object') {
          const tokenEntries = Object.entries(balanceResult.balance.tokens);
          if (tokenEntries.length > 0) {
            promptTokenMessage += "\n\nVos tokens disponibles:";
            tokenEntries.forEach(([tokenId, amount]) => {
              promptTokenMessage += `\n- ${tokenId}: ${amount}`;
            });
          }
        }
        
        // Demander l'ID du token
        await bot.sendMessage(
          currentChatId,
          promptTokenMessage,
          { reply_markup: { force_reply: true } }
        );
        return;
        
      case SEND_TOKEN_STATES.WAITING_FOR_TOKEN_ID:
        // L'utilisateur a fourni l'ID du token
        userInfo.tokenId = text;
        userInfo.state = SEND_TOKEN_STATES.WAITING_FOR_AMOUNT;
        userState.set(userId, userInfo);
        
        // Demander le montant à envoyer
        await bot.sendMessage(
          currentChatId,
          `Quelle quantité du token ${text} souhaitez-vous envoyer?`,
          { reply_markup: { force_reply: true } }
        );
        return;
        
      case SEND_TOKEN_STATES.WAITING_FOR_AMOUNT:
        // L'utilisateur a fourni le montant
        const amount = parseInt(text, 10) || 0;
        const toAccountId = userInfo.toAccountId;
        const tokenId = userInfo.tokenId;
        const addrType = userInfo.addressType || 'HEDERA'; // Par défaut
        
        // Vérifier si le montant est valide
        if (amount <= 0) {
          await bot.sendMessage(
            currentChatId,
            "Le montant doit être un nombre positif. Veuillez réessayer."
          );
          return;
        }
        
        // Réinitialiser l'état
        userState.set(userId, { ...userInfo, state: SEND_TOKEN_STATES.NONE });
        
        // Message d'information adapté au type d'identifiant
        const identType = addrType === 'PHONE' ? 'numéro de téléphone' : 'adresse Hedera';
        await bot.sendMessage(currentChatId, `Envoi de ${amount} tokens (${tokenId}) au ${identType} ${toAccountId} en cours...`);
        
        // Effectuer la transaction
        const result = await sendToken(userId, toAccountId, tokenId, amount);
        
        // Afficher le résultat
        if (result.success) {
          const message = `
✅ ${result.message}

*Détails de la transaction :*
Token ID: \`${result.tokenId}\`
Transaction ID: \`${result.transactionId}\`

[Voir dans l'explorateur](${result.explorerUrl})

Utilisez /balance pour vérifier votre nouveau solde.
`;
          await bot.sendMessage(currentChatId, message, { parse_mode: 'Markdown' });
        } else {
          await bot.sendMessage(currentChatId, `❌ ${result.message}`);
        }
        return;
    }
  }
}

/**
 * Handle conversation steps for sending HBAR
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handleSendConversation(bot, msg) {
  const userId = msg.from.id.toString();
  const userInfo = userState.get(userId);
  const msgChatId = msg.chat.id;
  const text = msg.text.trim();
  
  // Vérifier si l'utilisateur est en cours de processus d'envoi
  if (userInfo) {
    // Traitement des étapes de la conversation en cours
    const currentChatId = userInfo.chatId;
    
    // Gestion des différentes étapes de la conversation
    switch (userInfo.state) {
      case SEND_STATES.WAITING_FOR_ADDRESS_TYPE:
        // L'utilisateur a choisi le type d'adresse à utiliser
        let promptMessage = '';
        
        if (text.includes('Numéro') || text.includes('📱')) {
          // Option numéro de téléphone
          userInfo.addressType = 'PHONE';
          promptMessage = "Entrez le numéro de téléphone du destinataire (format: 0XXXXXXXXX ou +33XXXXXXXXX):";
        } else if (text.includes('Hedera') || text.includes('🔢')) {
          // Option adresse Hedera
          userInfo.addressType = 'HEDERA';
          promptMessage = "Entrez l'adresse Hedera du destinataire (format: 0.0.xxxx):";
        } else {
          // Option non reconnue
          await bot.sendMessage(
            currentChatId,
            "Je n'ai pas compris votre choix. Veuillez sélectionner une des options proposées.",
            { 
              reply_markup: {
                keyboard: [
                  ['📱 Numéro de téléphone'],
                  ['🔢 Adresse Hedera (0.0.xxxx)']
                ],
                one_time_keyboard: true,
                resize_keyboard: true
              }
            }
          );
          return;
        }
        
        // Mettre à jour l'état et demander l'adresse
        userInfo.state = SEND_STATES.WAITING_FOR_ADDRESS;
        userState.set(userId, userInfo);
        
        await bot.sendMessage(
          currentChatId,
          promptMessage,
          { reply_markup: { force_reply: true, remove_keyboard: true } }
        );
        return;
        
      case SEND_STATES.WAITING_FOR_ADDRESS:
        // L'utilisateur a fourni l'adresse de destination
        userInfo.toAccountId = text;
        userInfo.state = SEND_STATES.WAITING_FOR_AMOUNT;
        userState.set(userId, userInfo);
        
        // Type d'identifiant utilisé pour le message
        const identifierType = userInfo.addressType === 'PHONE' ? 'numéro de téléphone' : 'adresse Hedera';
        
        // Demander le montant à envoyer
        await bot.sendMessage(
          currentChatId,
          `Quelle quantité de HBAR souhaitez-vous envoyer au ${identifierType} ${text}?`,
          { reply_markup: { force_reply: true } }
        );
        return;
        
      case SEND_STATES.WAITING_FOR_AMOUNT:
        // L'utilisateur a fourni le montant
        const amount = text;
        const toAccountId = userInfo.toAccountId;
        const addrType = userInfo.addressType || 'HEDERA'; // Par défaut
        
        // Réinitialiser l'état
        userState.set(userId, { ...userInfo, state: SEND_STATES.NONE });
        
        // Message d'information adapté au type d'identifiant
        const identType = addrType === 'PHONE' ? 'numéro de téléphone' : 'adresse Hedera';
        await bot.sendMessage(currentChatId, `Envoi de ${amount} HBAR au ${identType} ${toAccountId} en cours...`);
        
        // Effectuer la transaction - même fonction pour les deux types, la résolution se fait automatiquement
        const result = await sendHbar(userId, toAccountId, amount);
        
        // Afficher le résultat
        if (result.success) {
          const message = `
✅ ${result.message}

*Détails de la transaction :*
Transaction ID: \`${result.transactionId}\`

[Voir dans l'explorateur](${result.explorerUrl})

Utilisez /balance pour vérifier votre nouveau solde.
`;
          await bot.sendMessage(currentChatId, message, { parse_mode: 'Markdown' });
        } else {
          await bot.sendMessage(currentChatId, `❌ ${result.message}`);
        }
        return;
    }
  }
  
  // Si l'utilisateur n'est pas dans une conversation, afficher un message d'aide
  await bot.sendMessage(
    msg.chat.id,
    "Désolé, je ne comprends pas cette commande. Utilisez /help pour voir la liste des commandes disponibles."
  );
}

/**
 * Handles natural language understanding with OpenAI
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handleNaturalLanguage(bot, msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const text = msg.text.trim();
  
  // D'abord, essayons des détections rapides pour éviter d'appeler OpenAI pour des requêtes simples
  
  // Vérifier si c'est une demande de solde avec des mots-clés simples
  if (isBalanceCheck(text)) {
    // Simuler l'appel à la commande balance
    await handleBalance(bot, msg);
    return;
  }
  
  // Vérifier si c'est une demande d'historique avec des mots-clés simples
  if (isHistoryCheck(text)) {
    // Simuler l'appel à la commande history
    await handleHistory(bot, msg);
    return;
  }
  
  // Vérifier si c'est une demande simple de création de token
  if (isCreateTokenRequest(text)) {
    // Simuler l'appel à la commande mint sans arguments
    await handleMint(bot, { ...msg, text: '/mint' });
    return;
  }
  
  // Vérifier si c'est une demande d'airdrops disponibles
  if (isGetAirdropsRequest(text)) {
    // Simuler l'appel à la commande claimairdrop
    await handleClaimAirdrop(bot, msg);
    return;
  }
  
  // Vérifier si c'est une demande de création d'airdrop
  if (isCreateAirdropRequest(text)) {
    // Simuler l'appel à la commande airdrop
    await handleAirdrop(bot, { ...msg, text: '/airdrop' });
    return;
  }
  
  // Vérifier si c'est une requête pour le plugin Eliza (interrogation de la blockchain)
  if (isElizaQuery(text)) {
    const chatId = msg.chat.id;
    
    await bot.sendMessage(chatId, "Interrogation de la blockchain en cours...");
    
    try {
      const elizaResult = await processWithEliza(userId, text);
      
      if (elizaResult.success) {
        await bot.sendMessage(chatId, elizaResult.response, { parse_mode: 'Markdown' });
      } else {
        await bot.sendMessage(chatId, `❌ ${elizaResult.error || "Erreur lors de l'interrogation de la blockchain"}`);
      }
    } catch (error) {
      console.error(`Erreur lors du traitement Eliza: ${error.message}`);
      await bot.sendMessage(chatId, `❌ Une erreur s'est produite lors de l'interrogation de la blockchain: ${error.message}`);
    }
    
    return;
  }
  
  // Pour les autres requêtes, utiliser OpenAI pour comprendre l'intention
  await bot.sendMessage(chatId, "Traitement de votre demande...");
  
  // Analyser l'intention avec OpenAI
  const intentResult = await analyzeIntent(userId, text);
  
  if (!intentResult.success) {
    await bot.sendMessage(
      chatId,
      `Désolé, je n'ai pas pu comprendre votre demande. ${intentResult.error || "Veuillez réessayer ou utiliser les commandes /help."}`,
      { parse_mode: 'Markdown' }
    );
    return;
  }
  
  // Gérer l'intention détectée
  switch (intentResult.action) {
    case 'check_balance':
      await handleBalance(bot, msg);
      break;
      
    case 'transfer_hbar':
      // Si les paramètres sont complets, initialiser directement le transfert
      if (intentResult.params.recipientId && intentResult.params.amount) {
        const toAccountId = intentResult.params.recipientId;
        const amount = intentResult.params.amount;
        
        await bot.sendMessage(chatId, `Envoi de ${amount} HBAR à ${toAccountId} en cours...`);
        
        const result = await sendHbar(userId, toAccountId, amount);
        
        if (result.success) {
          const message = `
✅ ${result.message}

*Détails de la transaction :*
Transaction ID: \`${result.transactionId}\`

[Voir dans l'explorateur](${result.explorerUrl})

Utilisez /balance pour vérifier votre nouveau solde.
`;
          await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
        } else {
          await bot.sendMessage(chatId, `❌ ${result.message}`);
        }
      } else {
        // Sinon, démarrer la conversation structurée normalement
        await handleSend(bot, msg);
      }
      break;
      
    case 'create_token':
      // Pour tout message de création de token, démarrer le processus interactif
      // (sauf si tous les paramètres sont déjà fournis)
      if (intentResult.params.name && intentResult.params.symbol && intentResult.params.initialSupply) {
        // Si tous les paramètres sont complets, créer directement le token
        const tokenInfo = {
          name: intentResult.params.name,
          symbol: intentResult.params.symbol,
          initialSupply: intentResult.params.initialSupply
        };
        
        await bot.sendMessage(chatId, 'Création de votre token en cours... Cela peut prendre un moment.');
        
        const result = await mintToken(userId, tokenInfo);
        
        if (result.success) {
          const message = `
✅ ${result.message}

*Informations du token :*
Token ID: \`${result.tokenId}\`
Nom: ${result.tokenName}
Symbole: ${result.tokenSymbol}
Offre initiale: ${result.initialSupply || 1000}

[Voir dans l'explorateur](${result.explorerUrl})

Utilisez /balance pour voir votre nouveau token dans votre portefeuille.
`;
          await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
        } else {
          await bot.sendMessage(chatId, `❌ ${result.message}`);
        }
      } else {
        // Sinon, démarrer la conversation structurée pour la création de token
        // Simuler une commande /mint sans arguments
        await handleMint(bot, { ...msg, text: '/mint' });
      }
      break;
      
    case 'get_history':
      const limit = intentResult.params.limit || 5;
      await handleHistory(bot, { ...msg, text: `/history ${limit}` });
      break;
      
    case 'create_topic':
      if (intentResult.params.topicName) {
        await bot.sendMessage(chatId, 'Création du topic HCS en cours...');
        
        const result = await createTopic(
          userId, 
          intentResult.params.topicName, 
          intentResult.params.submitKey || false
        );
        
        if (result.success) {
          const message = `
✅ Topic créé avec succès

*Informations du topic :*
Topic ID: \`${result.topicId}\`
Mémo: ${result.memo || intentResult.params.topicName}

[Voir dans l'explorateur](${result.explorerUrl})
`;
          await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
        } else {
          await bot.sendMessage(chatId, `❌ ${result.message}`);
        }
      } else {
        await bot.sendMessage(
          chatId,
          'Pour créer un topic, veuillez fournir un nom. Exemple: "Créer un topic nommé MonTopic"'
        );
      }
      break;
      
    case 'submit_message':
      if (intentResult.params.topicId && intentResult.params.message) {
        await bot.sendMessage(chatId, 'Envoi du message au topic HCS en cours...');
        
        const result = await submitTopicMessage(
          userId, 
          intentResult.params.topicId, 
          intentResult.params.message
        );
        
        if (result.success) {
          const message = `
✅ Message envoyé avec succès

*Détails :*
Topic ID: \`${result.topicId}\`
Message: ${result.message.substring(0, 50)}${result.message.length > 50 ? '...' : ''}
Sequence: ${result.sequence}

[Voir dans l'explorateur](${result.explorerUrl})
`;
          await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
        } else {
          await bot.sendMessage(chatId, `❌ ${result.message}`);
        }
      } else {
        await bot.sendMessage(
          chatId,
          'Pour envoyer un message à un topic, veuillez fournir un ID de topic et un message. Exemple: "Envoyer un message \'Bonjour\' au topic 0.0.12345"'
        );
      }
      break;
      
    case 'get_topic_messages':
      if (intentResult.params.topicId) {
        await bot.sendMessage(chatId, 'Récupération des messages du topic HCS en cours...');
        
        const result = await getTopicMessages(
          userId, 
          intentResult.params.topicId
        );
        
        if (result.success && result.messages && result.messages.length > 0) {
          let message = `📨 *Messages du Topic*\n\nTopic ID: \`${result.topicId}\`\n\n`;
          
          result.messages.forEach((msg, index) => {
            message += `*${index + 1}. Message*\n`;
            message += `Date: ${new Date(msg.consensusTimestamp).toLocaleString()}\n`;
            message += `Contenu: ${msg.message}\n`;
            message += `Séquence: ${msg.sequenceNumber}\n\n`;
          });
          
          await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
        } else if (result.success && (!result.messages || result.messages.length === 0)) {
          await bot.sendMessage(
            chatId,
            `Aucun message trouvé pour le topic ${result.topicId}`
          );
        } else {
          await bot.sendMessage(chatId, `❌ ${result.message}`);
        }
      } else {
        await bot.sendMessage(
          chatId,
          'Pour voir les messages d\'un topic, veuillez fournir un ID de topic. Exemple: "Voir les messages du topic 0.0.12345"'
        );
      }
      break;
      
    case 'transfer_token':
      if (intentResult.params.recipientId && intentResult.params.tokenId && intentResult.params.amount) {
        await bot.sendMessage(
          chatId, 
          `Envoi de ${intentResult.params.amount} tokens (${intentResult.params.tokenId}) à ${intentResult.params.recipientId} en cours...`
        );
        
        const result = await sendToken(
          userId, 
          intentResult.params.recipientId,
          intentResult.params.tokenId,
          intentResult.params.amount
        );
        
        if (result.success) {
          const message = `
✅ ${result.message}

*Détails de la transaction :*
Token ID: \`${result.tokenId}\`
Transaction ID: \`${result.transactionId}\`

[Voir dans l'explorateur](${result.explorerUrl})

Utilisez /balance pour vérifier votre nouveau solde.
`;
          await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
        } else {
          await bot.sendMessage(chatId, `❌ ${result.message}`);
        }
      } else {
        await bot.sendMessage(
          chatId,
          'Pour envoyer des tokens, veuillez fournir un ID de compte destinataire, un ID de token et un montant. Exemple: "Envoyer 100 tokens 0.0.12345 à 0.0.67890"'
        );
      }
      break;
      
    case 'claim_airdrop':
      // Utiliser la fonction handleClaimAirdrop pour démarrer le processus de réclamation d'airdrop
      await handleClaimAirdrop(bot, msg);
      break;
      
    case 'get_airdrops':
      // Afficher les airdrops disponibles
      await handleClaimAirdrop(bot, msg);
      break;
      
    case 'create_airdrop':
      // Démarrer le processus d'airdrop
      await handleAirdrop(bot, msg);
      break;
      
    case 'unknown':
    default:
      await bot.sendMessage(
        chatId,
        "Je ne suis pas sûr de comprendre votre demande. Essayez d'être plus précis ou utilisez les commandes avec /help pour voir les options disponibles."
      );
      break;
  }
}

/**
 * Register all command handlers with the bot
 * @param {TelegramBot} bot - Telegram bot instance
 */
/**
 * Définit la langue directement sans passer par les callbacks
 * @param {string} userId - ID de l'utilisateur
 * @param {string} newLang - Code de langue ('fr' ou 'en')
 * @param {TelegramBot} bot - Instance du bot Telegram
 * @param {number} chatId - ID du chat
 */
async function setLanguageDirectly(userId, newLang, bot, chatId) {
  console.log(`Setting language directly for user ${userId} to ${newLang}`);
  
  try {
    const success = setUserLanguage(userId, newLang);
    console.log(`Language set result: ${success}`);
    
    if (success) {
      // Vérifier la langue après le changement
      const currentLang = getUserLanguage(userId);
      console.log(`User ${userId} language is now: ${currentLang}`);
      
      // Récupérer le message de confirmation dans la nouvelle langue
      const confirmMessage = translate(userId, 'language_changed');
      console.log(`Confirmation message: ${confirmMessage}`);
      
      // Envoyer un message de confirmation
      await bot.sendMessage(
        chatId,
        confirmMessage
      );
      console.log(`Confirmation message sent to user ${userId}`);
      
      // Envoyer un message d'aide dans la nouvelle langue
      setTimeout(async () => {
        const helpMessage = translate(userId, 'help');
        console.log(`Help message length: ${helpMessage.length} chars`);
        
        await bot.sendMessage(
          chatId,
          helpMessage
        );
        console.log(`Help message sent to user ${userId}`);
      }, 500);
    } else {
      console.error(`Failed to set language for user ${userId}`);
      await bot.sendMessage(
        chatId,
        "Erreur lors du changement de langue. Veuillez réessayer."
      );
    }
  } catch (error) {
    console.error(`Error in setLanguageDirectly: ${error.message}`);
    await bot.sendMessage(
      chatId,
      `Erreur technique: ${error.message}`
    );
  }
}

/**
 * Handles the /language command to change the user's language preference
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handleLanguage(bot, msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  console.log(`Language command received from user ${userId}`);
  
  // Extraire les arguments de la commande
  const args = msg.text.split(/\s+/).slice(1);
  console.log(`Language args: ${JSON.stringify(args)}`);
  
  // Si un argument est fourni (comme "en" ou "fr"), utiliser directement
  if (args.length > 0) {
    const langArg = args[0].toLowerCase();
    console.log(`Detected language arg: ${langArg}`);
    
    if (langArg === 'en' || langArg === 'english' || langArg === 'anglais') {
      console.log(`Setting language to English for user ${userId}`);
      return setLanguageDirectly(userId, LANGUAGES.EN, bot, chatId);
    } else if (langArg === 'fr' || langArg === 'french' || langArg === 'français') {
      console.log(`Setting language to French for user ${userId}`);
      return setLanguageDirectly(userId, LANGUAGES.FR, bot, chatId);
    }
  }
  
  // Sinon, afficher un message avec des options simples (pas de inline keyboard)
  console.log(`Showing language selection menu to user ${userId}`);
  const message = `
${translate(userId, 'language_selection')}

Pour choisir le français: /language fr
To choose English: /language en
  `;
  
  try {
    await bot.sendMessage(chatId, message);
    console.log(`Language menu sent successfully to user ${userId}`);
  } catch (error) {
    console.error(`Error sending language menu: ${error.message}`);
  }
}

function registerCommands(bot) {
  // Réactivation des modules d'airdrop avec TokenAirdropTransaction
  airdropModule.initializeWithSharedState(userState);
  console.log("État des utilisateurs partagé avec le module airdrop-commands");
  
  // Initialiser le module de gestion des boutons avec l'état partagé
  const buttonHandlers = require('./button-handlers');
  buttonHandlers.initialize(userState, AIRDROP_STATES);
  console.log("État des utilisateurs partagé avec le module button-handlers");
  
  // Define command handlers
  // Supprimé le gestionnaire de /start car il est déjà dans language/handler.js
  // ce qui causait un double affichage des menus
  // bot.onText(/\/start/, msg => handleStart(bot, msg));
  
  // Supprimé le gestionnaire de /help car il est déjà dans language/handler.js
  // ce qui pourrait causer des problèmes similaires
  // bot.onText(/\/help/, msg => handleHelp(bot, msg));
  
  bot.onText(/\/createwallet/, msg => handleCreateWallet(bot, msg));
  bot.onText(/\/balance/, msg => handleBalance(bot, msg));
  bot.onText(/\/send(.*)/, msg => handleSend(bot, msg));
  bot.onText(/\/sendtoken(.*)/, msg => handleSendToken(bot, msg));
  bot.onText(/\/history(.*)/, msg => handleHistory(bot, msg));
  bot.onText(/\/mint(.*)/, msg => handleMint(bot, msg));
  bot.onText(/\/associate(.*)/, msg => handleAssociate(bot, msg));
  
  // Réactiver les commandes d'airdrop avec TokenAirdropTransaction
  bot.onText(/\/airdrop(.*)/, msg => handleAirdrop(bot, msg));
  bot.onText(/\/claimairdrop(.*)/, msg => handleClaimAirdrop(bot, msg));
  
  // Commandes de campagnes toujours désactivées 
  // bot.onText(/\/campaign(.*)/, msg => handleCampaign(bot, msg));
  // bot.onText(/\/claim(.*)/, msg => handleClaim(bot, msg));
  // bot.onText(/\/mycampaigns(.*)/, msg => handleMyCampaigns(bot, msg));
  // bot.onText(/\/campaigninfo(.*)/, msg => handleCampaignInfo(bot, msg));
  // bot.onText(/\/campaignstatus(.*)/, msg => handleCampaignStatus(bot, msg));
  // Nous avons désactivé l'ancien gestionnaire de langue qui causait des conflits
  // bot.onText(/\/(language|langue)(.*)/, msg => handleLanguage(bot, msg));
  
  // Gestionnaire pour les callbacks des boutons
  bot.on('callback_query', async (callbackQuery) => {
    console.log(`Callback received: ${callbackQuery.data} from user ${callbackQuery.from.id}`);
    
    // Essayer de traiter avec le gestionnaire des boutons
    const handled = await buttonHandlers.handleButtonAction(callbackQuery);
    
    // Si le callback n'a pas été traité, retourner un message générique
    if (!handled) {
      console.log(`Unhandled callback: ${callbackQuery.data}`);
      await bot.answerCallbackQuery(callbackQuery.id, { 
        text: "Cette action n'est plus disponible ou a expiré."
      });
    }
  });
  
  // Handler pour les messages normaux
  bot.on('message', async (msg) => {
    // On ne traite que les messages textuels
    if (!msg.text) return;
    
    const userId = msg.from.id.toString();
    const isCommand = msg.text.startsWith('/');
    
    // Si c'est une commande, vérifier si c'est une commande setlang connue
    if (isCommand) {
      // Vérifier si c'est une commande de langue
      const isLanguageCommand = msg.text.match(/^\/(setlang|language|langue)(\s+.*)?$/i);
      
      // Si c'est bien une commande langue, ne rien faire car le gestionnaire spécifique s'en occupera
      if (isLanguageCommand) {
        console.log(`Skipping natural language processing for language command from user ${userId}`);
        return;
      }
    }
    
    // Si ce n'est pas une commande, traiter comme un message normal
    if (!isCommand) {
      // Vérifier si nous sommes au milieu d'une conversation structurée
      const userInfo = userState.get(userId);
      
      if (userInfo) {
        // Vérifier si nous sommes dans une conversation téléphonique lors du démarrage
        if (userInfo.state === START_STATES.WAITING_FOR_PHONE) {
          // Si l'utilisateur est dans une conversation de collecte de numéro de téléphone, continuer celle-ci
          handlePhoneNumberConversation(bot, msg);
          return;
        }
        
        // Vérifier si nous sommes dans une conversation d'envoi HBAR
        if (userInfo.state && [SEND_STATES.WAITING_FOR_ADDRESS_TYPE, SEND_STATES.WAITING_FOR_ADDRESS, SEND_STATES.WAITING_FOR_AMOUNT].includes(userInfo.state)) {
          // Si l'utilisateur est dans une conversation d'envoi HBAR, continuer celle-ci
          handleSendConversation(bot, msg);
          return;
        }
        
        // Vérifier si nous sommes dans une conversation d'envoi de token
        if (userInfo.state && Object.values(SEND_TOKEN_STATES).includes(userInfo.state)) {
          // Si l'utilisateur est dans une conversation d'envoi de token, continuer celle-ci
          handleSendTokenConversation(bot, msg);
          return;
        }
        
        // Vérifier si nous sommes dans une conversation de création de token
        if (userInfo.tokenInfo && [MINT_STATES.WAITING_FOR_TYPE, MINT_STATES.WAITING_FOR_NAME, 
                                  MINT_STATES.WAITING_FOR_SYMBOL, MINT_STATES.WAITING_FOR_SUPPLY].includes(userInfo.state)) {
          // Si l'utilisateur est dans une conversation de création de token, continuer celle-ci
          handleMintConversation(bot, msg);
          return;
        }
        
        // Vérifier si nous sommes dans une conversation d'association de token
        if (userInfo.state === ASSOCIATE_STATES.WAITING_FOR_TOKEN_ID) {
          // Si l'utilisateur est dans une conversation d'association de token, continuer celle-ci
          handleAssociateConversation(bot, msg);
          return;
        }
        
        // Vérifier si nous sommes dans une conversation de transfert forcé
        if (Object.values(FORCE_TRANSFER_STATES).includes(userInfo.state)) {
          const handled = await handleForceTransferConversation(bot, msg);
          if (handled) return;
        }
        
        // Vérifier si nous sommes dans une conversation d'airdrop, de campagne ou de réclamation
        if (userInfo.state && 
            (userInfo.state.toString().startsWith('waiting_for_') || 
             Object.values(AIRDROP_STATES).includes(userInfo.state) || 
             Object.values(CAMPAIGN_STATES).includes(userInfo.state) ||
             Object.values(CLAIM_STATES).includes(userInfo.state))) {
          
          console.log(`[DEBUG] Utilisateur ${userId} est dans une conversation airdrop avec état: ${userInfo.state}`);
          console.log(`[DEBUG] Message reçu: "${msg.text}"`);
          console.log(`[DEBUG] Données de conversation:`, JSON.stringify(userInfo, null, 2));
          
          // Traiter la conversation d'airdrop avec le gestionnaire spécifique
          console.log(`[DEBUG] Transfert de la conversation airdrop au gestionnaire pour utilisateur ${userId} avec état: ${userInfo.state}`);
          const result = await handleAirdropConversation(bot, msg);
          if (result) return;
          
          // Si nous arrivons ici, la conversation n'a pas été traitée correctement
          console.log(`[WARN] Conversation airdrop non traitée pour l'utilisateur ${userId} avec état ${userInfo.state}`);
        }
      }
      
      // Si l'utilisateur n'est pas dans une conversation, utiliser OpenAI pour comprendre l'intention
      handleNaturalLanguage(bot, msg);
    }
  });
  
  // Set up bot commands for Telegram menu
  bot.setMyCommands([
    { command: "createwallet", description: "Créer un nouveau wallet" },
    { command: "balance", description: "Vérifier le solde de votre wallet" },
    { command: "send", description: "Envoyer des HBAR à un autre compte" },
    { command: "sendtoken", description: "Envoyer des tokens à un autre compte" },
    { command: "history", description: "Consulter l'historique de vos transactions" },
    { command: "mint", description: "Créer un nouveau token" },
    { command: "associate", description: "Associer un token à votre compte" },
    // Réactiver les commandes d'airdrop avec TokenAirdropTransaction
    { command: "airdrop", description: "Créer un airdrop de tokens" },
    { command: "claimairdrop", description: "Réclamer des tokens d'un airdrop" },
    { command: "forcetransfer", description: "Transférer un token directement (Admin)" },
    { command: "setlang", description: "Changer la langue (FR/EN)" },
    { command: "help", description: "Afficher de l'aide" },
  ]);
}

/**
 * Handle phone number collection conversation
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handlePhoneNumberConversation(bot, msg) {
  const userId = msg.from.id.toString();
  const userInfo = userState.get(userId);
  const msgChatId = msg.chat.id;
  const text = msg.text.trim();
  const firstName = msg.from.first_name || 'l\'ami';
  
  // Vérifier que l'état est bien celui attendu
  if (userInfo && userInfo.state === START_STATES.WAITING_FOR_PHONE) {
    // Valider le format du numéro de téléphone (format simple: commence par 0 ou +)
    const phoneNumberPattern = /^[0+][0-9\s\-\(\)\.]{5,20}$/;
    
    if (!phoneNumberPattern.test(text)) {
      await bot.sendMessage(
        msgChatId,
        "Le format du numéro de téléphone n'est pas valide. Veuillez réessayer avec un format comme 0XXXXXXXXX ou +336XXXXXXXX:",
        { reply_markup: { force_reply: true } }
      );
      return;
    }
    
    const phoneNumber = text.trim();
    console.log(`Numéro de téléphone reçu de ${userId}: ${phoneNumber}`);
    
    // Vérifier si l'utilisateur est déjà dans notre base avec un portefeuille
    const userData = userInfo.userData || {};
    
    if (userData.accountId) {
      // Utilisateur existant, mettre à jour son numéro de téléphone
      try {
        const { query } = require('../storage/db');
        await query(
          'UPDATE user_wallets SET phone_number = $1 WHERE user_id = $2',
          [phoneNumber, userId]
        );
        
        await bot.sendMessage(
          msgChatId,
          `Merci ${firstName} ! Votre numéro de téléphone a été enregistré.`
        );
        
        // Réinitialiser l'état et afficher le menu d'aide
        userState.set(userId, { state: START_STATES.NONE });
        
        // Afficher les boutons d'aide
        const { sendHelpWithButtons } = require('./language/handler');
        await sendHelpWithButtons(bot, userId, msgChatId);
      } catch (error) {
        console.error(`Erreur lors de la mise à jour du numéro de téléphone: ${error.message}`);
        await bot.sendMessage(
          msgChatId,
          "Une erreur s'est produite lors de l'enregistrement de votre numéro. Veuillez réessayer plus tard."
        );
      }
    } else {
      // Nouvel utilisateur, créer un portefeuille avec le numéro de téléphone
      await bot.sendMessage(
        msgChatId,
        "Merci ! Création de votre portefeuille Hedera en cours... Cela peut prendre un moment."
      );
      
      try {
        const username = msg.from.username || null;
        const result = await createAccount(userId, username, phoneNumber);
        
        if (result.success) {
          const message = `
✅ ${result.message}

*Vos informations de compte Hedera :*

Account ID: \`${result.accountId}\`
EVM Address: \`${result.evmAddress}\`

*Clés du compte :*
Private Key: \`${result.privateKey}\`
Public Key: \`${result.publicKey}\`

*Transaction :*
Transaction ID: \`${result.transactionId}\`
[Voir dans l'explorateur](${result.explorerUrl})

IMPORTANT : Conservez ces informations en lieu sûr, surtout la clé privée.
Utilisez /balance pour vérifier votre solde.
`;
          
          await bot.sendMessage(msgChatId, message, { parse_mode: 'Markdown' });
        } else {
          await bot.sendMessage(msgChatId, `❌ ${result.message}`);
        }
        
        // Réinitialiser l'état
        userState.set(userId, { state: START_STATES.NONE });
      } catch (error) {
        console.error(`Erreur lors de la création du portefeuille: ${error.message}`);
        await bot.sendMessage(
          msgChatId,
          "Une erreur s'est produite lors de la création de votre portefeuille. Veuillez réessayer plus tard."
        );
      }
    }
  }
}

/**
 * Handles the /associate command
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handleAssociate(bot, msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const args = msg.text.split(' ').slice(1);
  
  // Si un token ID est fourni directement en argument
  if (args.length > 0) {
    const tokenId = args[0];
    
    await bot.sendMessage(chatId, `Association du token ${tokenId} en cours...`);
    
    const result = await associateToken(userId, tokenId);
    
    if (result.success) {
      let message;
      if (result.alreadyAssociated) {
        message = `ℹ️ ${result.message}`;
      } else {
        message = `
✅ ${result.message}

*Détails de l'association :*
Token ID: \`${result.tokenId}\`
Compte: \`${result.accountId}\`

${result.transactionId ? `[Voir la transaction dans l'explorateur](${result.explorerUrl})` : ''}

Vous pouvez maintenant recevoir ce token dans votre portefeuille.
`;
      }
      
      await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } else {
      await bot.sendMessage(chatId, `❌ ${result.message}`);
    }
    return;
  }
  
  // Sinon, démarrer le processus interactif d'association de token
  userState.set(userId, {
    state: ASSOCIATE_STATES.WAITING_FOR_TOKEN_ID,
    chatId: chatId
  });
  
  // Demander l'ID du token à associer
  await bot.sendMessage(
    chatId, 
    "Quel token souhaitez-vous associer à votre compte? Entrez l'ID du token (format: 0.0.xxxx)",
    { reply_markup: { force_reply: true } }
  );
}

/**
 * Handle conversation steps for associating a token
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handleAssociateConversation(bot, msg) {
  const userId = msg.from.id.toString();
  const userInfo = userState.get(userId);
  const msgChatId = msg.chat.id;
  const text = msg.text.trim();
  
  // Vérifier si l'utilisateur est en cours de processus d'association de token
  if (userInfo && userInfo.state === ASSOCIATE_STATES.WAITING_FOR_TOKEN_ID) {
    const currentChatId = userInfo.chatId;
    
    // Valider le format du tokenId (simple vérification)
    if (!text.match(/^\d+\.\d+\.\d+$/)) {
      await bot.sendMessage(
        currentChatId,
        "Format de Token ID invalide. Le format attendu est 0.0.xxxx. Veuillez réessayer :"
      );
      return;
    }
    
    // Réinitialiser l'état de l'utilisateur
    userState.set(userId, { state: ASSOCIATE_STATES.NONE });
    
    // Associer le token
    await bot.sendMessage(currentChatId, `Association du token ${text} en cours...`);
    
    const result = await associateToken(userId, text);
    
    if (result.success) {
      let message;
      if (result.alreadyAssociated) {
        message = `ℹ️ ${result.message}`;
      } else {
        message = `
✅ ${result.message}

*Détails de l'association :*
Token ID: \`${result.tokenId}\`
Compte: \`${result.accountId}\`

${result.transactionId ? `[Voir la transaction dans l'explorateur](${result.explorerUrl})` : ''}

Vous pouvez maintenant recevoir ce token dans votre portefeuille.
`;
      }
      
      await bot.sendMessage(currentChatId, message, { parse_mode: 'Markdown' });
    } else {
      await bot.sendMessage(currentChatId, `❌ ${result.message}`);
    }
  }
}

/**
 * Handles the /forcetransfer command (Admin only)
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 */
async function handleForceTransfer(bot, msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  // Vérification des permissions d'administrateur (à adapter selon votre système)
  // Dans cet exemple, toute personne peut utiliser la commande pour simplifier les tests
  
  // Réinitialiser l'état pour commencer un nouveau transfert forcé
  userState.set(userId, {
    state: FORCE_TRANSFER_STATES.WAITING_FOR_RECIPIENT,
    chatId: chatId,
    forceTransfer: {
      recipient: null,
      tokenId: null,
      amount: null
    }
  });
  
  // Demander le destinataire
  await bot.sendMessage(
    chatId, 
    "À quel compte Hedera souhaitez-vous envoyer des tokens? (ID Hedera, ID Telegram, nom d'utilisateur ou numéro de téléphone)",
    { reply_markup: { force_reply: true } }
  );
}

/**
 * Handle conversation flow for force transfer
 * @param {TelegramBot} bot - Telegram bot instance
 * @param {object} msg - Telegram message object
 * @returns {Promise<boolean>} True if the message was handled as part of a force transfer conversation
 */
async function handleForceTransferConversation(bot, msg) {
  const userId = msg.from.id.toString();
  const userInfo = userState.get(userId);
  const msgChatId = msg.chat.id;
  const text = msg.text.trim();
  
  // Vérifier si l'utilisateur est dans une conversation de transfert forcé
  if (!userInfo || !Object.values(FORCE_TRANSFER_STATES).includes(userInfo.state)) {
    return false;
  }
  
  const currentChatId = userInfo.chatId;
  
  switch (userInfo.state) {
    case FORCE_TRANSFER_STATES.WAITING_FOR_RECIPIENT:
      // L'utilisateur a entré un identifiant de destinataire
      await bot.sendMessage(currentChatId, `Recherche du compte pour: ${text}...`);
      
      // Résoudre l'identifiant fourni en un ID de compte Hedera
      const { resolveToAccountId } = require('../utils/identifiers');
      const accountId = await resolveToAccountId(text);
      
      if (!accountId) {
        await bot.sendMessage(
          currentChatId,
          `❌ Impossible de trouver un compte Hedera pour l'identifiant "${text}". Veuillez réessayer avec un autre identifiant:`,
          { reply_markup: { force_reply: true } }
        );
        return true;
      }
      
      // Mettre à jour l'état avec le destinataire et passer à l'étape suivante
      userInfo.forceTransfer.recipient = accountId;
      userInfo.state = FORCE_TRANSFER_STATES.WAITING_FOR_TOKEN_ID;
      userState.set(userId, userInfo);
      
      await bot.sendMessage(
        currentChatId,
        `✅ Compte trouvé: ${accountId}\n\nEntrez maintenant l'ID du token à transférer (format: 0.0.xxxx):`,
        { reply_markup: { force_reply: true } }
      );
      break;
      
    case FORCE_TRANSFER_STATES.WAITING_FOR_TOKEN_ID:
      // L'utilisateur a entré un ID de token
      // Vérifier le format du token ID
      if (!text.match(/^\d+\.\d+\.\d+$/)) {
        await bot.sendMessage(
          currentChatId,
          "Format de Token ID invalide. Le format attendu est 0.0.xxxx. Veuillez réessayer:",
          { reply_markup: { force_reply: true } }
        );
        return true;
      }
      
      // Mettre à jour l'état avec le token ID et passer à l'étape suivante
      userInfo.forceTransfer.tokenId = text;
      userInfo.state = FORCE_TRANSFER_STATES.WAITING_FOR_AMOUNT;
      userState.set(userId, userInfo);
      
      await bot.sendMessage(
        currentChatId,
        `Combien de tokens ${text} souhaitez-vous transférer à ${userInfo.forceTransfer.recipient}?`,
        { reply_markup: { force_reply: true } }
      );
      break;
      
    case FORCE_TRANSFER_STATES.WAITING_FOR_AMOUNT:
      // L'utilisateur a entré un montant
      const amount = parseInt(text, 10);
      
      if (isNaN(amount) || amount <= 0) {
        await bot.sendMessage(
          currentChatId,
          "Le montant doit être un nombre entier positif. Veuillez réessayer:",
          { reply_markup: { force_reply: true } }
        );
        return true;
      }
      
      // Réinitialiser l'état
      const recipientId = userInfo.forceTransfer.recipient;
      const tokenId = userInfo.forceTransfer.tokenId;
      userState.set(userId, { state: FORCE_TRANSFER_STATES.NONE });
      
      // Exécuter le transfert direct
      await bot.sendMessage(
        currentChatId,
        `🔄 Transfert de ${amount} tokens ${tokenId} vers ${recipientId} en cours...`
      );
      
      try {
        const { executeAirdropTransfer } = require('../hedera/tokens');
        const result = await executeAirdropTransfer(userId, recipientId, tokenId, amount);
        
        if (result.success) {
          const message = `
✅ ${result.message}

*Détails du transfert:*
De: \`${result.fromAccount}\`
À: \`${result.toAccount}\`
Token ID: \`${result.tokenId}\`
Montant: ${result.amount}

*Transaction:*
[Voir sur Hedera Explorer](${result.explorerUrl})
[Voir sur HashScan](${result.hashscanUrl})

Le destinataire peut maintenant réclamer son airdrop s'il apparaît dans ses airdrops disponibles.
`;
          await bot.sendMessage(currentChatId, message, { parse_mode: 'Markdown' });
        } else {
          await bot.sendMessage(currentChatId, `❌ ${result.message}`);
        }
      } catch (error) {
        console.error('Erreur lors du transfert forcé:', error);
        await bot.sendMessage(
          currentChatId,
          `❌ Une erreur s'est produite lors du transfert: ${error.message}`
        );
      }
      break;
  }
  
  return true;
}

module.exports = {
  registerCommands,
  handleStart,
  handleHelp,
  handleCreateWallet,
  handleBalance,
  handleSend,
  handleSendToken,
  handleHistory,
  handleMint,
  handleMintConversation,
  handleSendConversation,
  handleSendTokenConversation,
  handleNaturalLanguage,
  handlePhoneNumberConversation,
  // Fonctions d'association de token
  handleAssociate,
  handleAssociateConversation,
  // Fonction de transfert forcé pour admin
  handleForceTransfer,
  handleForceTransferConversation,
  // Fonctions d'airdrop temporairement désactivées pour refactoring
  // handleAirdrop,
  // handleClaimAirdrop,
  // handleAirdropConversation,
  // Exporter les états pour qu'ils soient disponibles ailleurs
  START_STATES,
  SEND_STATES,
  MINT_STATES,
  ASSOCIATE_STATES,
  FORCE_TRANSFER_STATES,
  AIRDROP_STATES,
  CAMPAIGN_STATES,
  CLAIM_STATES,
  // Exporter l'état utilisateur pour le partager
  userState
};
